package com.portfolio.FP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FpApplicationTests {

	@Test
	void contextLoads() {
	}

}
